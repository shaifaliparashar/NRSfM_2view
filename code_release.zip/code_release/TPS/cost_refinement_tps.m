function [F, J] = cost_refinement_tps(x,q1,N,C1,D,V,EpsilonLambda1, id10) %[F, J]
F=[];
JF=[];
L1 = x;
%p1 = q1;
[M1, M2]=TPSCoeffDiff(q1,L1,C1,1e-4,EpsilonLambda1);
p1= M1*L1;
d_p1=M2*L1;

d_p1u=d_p1(1:2:end,:);
d_p1v=d_p1(2:2:end,:);

n = [-d_p1u, -d_p1v, p1 + q1(1,:)'.*d_p1u+q1(2,:)'.*d_p1v]';
norm_n = sqrt((-d_p1u).^2 + (-d_p1v).^2 + (p1 + q1(1,:)'.*d_p1u+q1(2,:)'.*d_p1v).^2);
%n = n/norm_n;


% d_p1t = d_p1';
% d_p1u = d_p1t(:,1:3:end);
% d_p1v = d_p1t(:,2:3:end);

% n = cross(d_p1u, d_p1v)';% d_p1t(:,3:3:end);


for i = id10
%     nc = [d_p1u(i);d_p1v(i)];
%     NN = [N(1,i)/sqrt(1-q1(1,i)^2);N(2,i)];
    nc = n(:,i)/norm_n(i);%/norm(n(:,i));
    F = [F;nc-N(:,i)];
    %JF = [JF,[-M2(2*(i-1)+1,:); -M2(2*(i-1)+2,:); M1(i,:)+ q1(1,i)*M2(2*(i-1)+1,:)+q1(2,i)*M2(2*(i-1)+2,:)]'];
    JF = [JF,(1/norm_n(i)*[-M2(2*(i-1)+1,:); -M2(2*(i-1)+2,:); M1(i,:)+ q1(1,i)*M2(2*(i-1)+1,:)+q1(2,i)*M2(2*(i-1)+2,:)]-n(:,i)/norm_n(i)^3*(n(1,i)*-M2(2*(i-1)+1,:)+n(2,i)*-M2(2*(i-1)+2,:)+n(3,i)*(M1(i,:)+q1(1,i)*M2(2*(i-1)+1,:)+q1(2,i)*M2(2*(i-1)+2,:))))'];
    %JF = [JF;ones(3,25)]; 
    %F = [F; p1(i,:)'-Q1([1,3,2],i)];
end

    
% 
% M21 = M2(1:2:end,:);
% M22 = M2(2:2:end,:);
% for i=1:length(k1)
%     w=0;
%     if k1(i)~=0 && k2(i)~=0
% %         idx = idn(i,2:end);
% %         idx(idx==0)=[]; idx(k1(idx==0))=[];
% %         n1 = [k1(i);k2(i);1-q1(1,i)*k1(i)-q1(2,i)*k2(i)]; n1 = n1/norm(n1);
% %         
% %         if ~isempty(idx)
% %             n = [k1(idx);k2(idx);1-q1(1,idx).*k1(idx)-q1(2,idx).*k2(idx)];
% %             n = n./repmat(sqrt(sum(n.^2)),size(n,1),1);
% %             idx = find(n(1,:)==0 & n(2,:)==0); n(:,idx)=[];
% %             if size(n,2)>=5
% %                 d = acosd(sum(repmat(n1',size(n,2),1)'.*n));
% %                 w = 1/std(d);
% %             end
% %         end
%          w=1;
%     end
%     F1(i) = w*(k1(i) - (-d_p1u(i)/p1(i)));
%     F2(i) = w*(k2(i) - (-d_p1v(i)/p1(i)));
%     JF1(i,:)  =  w*(M21(i,:)./p1(i) - (d_p1u(i)/(p1(i)^2)).*M1(i,:));
%     JF2(i,:)  =  w*(M22 (i,:)./p1(i) - (d_p1v(i)/(p1(i)^2)).*M1(i,:));
% end
% %smoothness
Fs= D*V'*L1;
 Js = D*V';
% % %Js=blkdiag(Js,Js,Js);
Fs = Fs';
 F = [F', 1e-3*Fs];

J = [JF';1e-3*Js];
end