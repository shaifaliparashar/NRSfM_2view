function [Pref1] = refine_frame_tps(N, M, id10) %Pref1 pour jacobienne

KLims= [min(M(:,1))-1e-1 max(M(:,1))+1e-1,  min(M(:,2))-1e-1 max(M(:,2))+1e-1];
C1=TPSGenerateCenters(10,KLims);
%C1 = Q1';
EpsilonLambda1=TPSEpsilonLambda(C1,1e-4);

q1 = [M(:,1),M(:,2)]';
%N = [N(1,:); N(3,:); N(2,:)];
M=M'; 
 %M = [M(1,:); M(3,:); M(2,:)];

[L1,ZTZ1]=TPSWfromfeatures(q1,ones(1,size(q1,2)),C1,1e-4,1e-4,EpsilonLambda1); % pas pour Jacobienne

%[L1,ZTZ1]=TPSWfromfeatures(q1,M,C1,1e-16,1e-4,EpsilonLambda1);%pour Jacobienne

% [~,Pest1]=TPSWarpDiff(q1,L1,C1,1e-4,EpsilonLambda1);
[U, S, V]= svd(ZTZ1);
D=sqrt(S);
opt = optimset('Jacobian','on','Display','iter','MaxIter',100, 'DerivativeCheck','on','UseParallel',false);
fun = @(x)cost_refinement_tps(x,q1,N,C1,D,V,EpsilonLambda1, id10);

[L,~]=lsqnonlin(fun,L1,[],[],opt);
[~,Pe1]=TPSWarpDiff(q1,L,C1,1e-4,EpsilonLambda1);
% Pe1=[q1;Pe1/25000];
% [M1, ~]=TPSCoeffDiff(q1,L,C1,1e-4,EpsilonLambda1);
% Pe1= M1*L;

Pref1 = Pe1.*[q1;ones(1,size(q1,2))];
% Pref = Pref1;
end

