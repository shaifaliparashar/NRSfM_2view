function Pe=calculate_depth(N,u,v,dense)
P_e = zeros(size(N));
if dense
    un = u(1:dense:end);
    vn = v(1:dense:end);
else
    un = u;
    vn = v;
end
idx = find(N(1,:)~=0 & un~=0);
if ~isempty(idx)
    k1 = N(1,idx)./(un(idx).*N(1,idx)+vn(idx).*N(2,idx)+N(3,idx));
    k2 = N(2,idx)./(un(idx).*N(1,idx)+vn(idx).*N(2,idx)+N(3,idx));
    k1(isnan(k1))=0; k1(isinf(k1))=0; k2(isnan(k2))=0; k2(isinf(k2))=0;
    
    P_e(:,idx) = refine_frame_tps([un(idx);vn(idx)],k1,k2);
    Pe= estimate_points(P_e,[u;v],[un;vn],1e-4);
else
    Pe =zeros(3,length(u));
end

