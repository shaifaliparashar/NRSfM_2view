function [Ncm] = compute_H(u, v, ub, vb, a, b, c, d, t1, t2,th_min)

[Nc,Hcond] = compute_analytical_normals_test(a,b,c,d,t1,t2,u,v,ub,vb,th_min);
Nc(isnan(Nc))=0;
nc1 = Nc(1:3:end,:); nc2 = Nc(2:3:end,:); nc3 = Nc(3:3:end,:);
Ncm = zeros(3,size(Nc,2));

    for i=1:size(Nc,2)
        Ncm(:,i)=[median(nonzeros(nc1(:,i))); median(nonzeros(nc2(:,i))); median(nonzeros(nc3(:,i)))];
    end      

Ncm = Ncm./repmat(sqrt(sum(Ncm.^2)),3,1);
Ncm(isnan(Ncm))=0;
