function [Nc,Hcond] = compute_analytical_normals_test(a,b,c,d,t1,t2,u,v,ub,vb,th_min)


% T
h11 = a+t1.*u;
h12 = b+t1.*v;
h13 = t1;
h21 = c+t2.*u;
h22 = d+t2.*v;
h23 = t2;
h31 = u-ub.*(a+t1.*u)-vb.*(c+t2.*u);
h32 = v-ub.*(b+t1.*v)-vb.*(d+t2.*v);
h33 = -t1.*ub-t2.*vb+1.0;

% 
% % % H^-T*H^-1 = T^-1*T^-T
h_11 = (h12.*h23-h13.*h22).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h12.*h33-h13.*h32).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h22.*h33-h23.*h32).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;
h_12 = -(h11.*h23-h13.*h21).*(h12.*h23-h13.*h22).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2-(h11.*h33-h13.*h31).*(h12.*h33-h13.*h32).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2-(h21.*h33-h23.*h31).*(h22.*h33-h23.*h32).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;
h_13 = (h11.*h22-h12.*h21).*(h12.*h23-h13.*h22).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h11.*h32-h12.*h31).*(h12.*h33-h13.*h32).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h21.*h32-h22.*h31).*(h22.*h33-h23.*h32).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;
h_22 = (h11.*h23-h13.*h21).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h11.*h33-h13.*h31).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h21.*h33-h23.*h31).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;
h_23 = -(h11.*h22-h12.*h21).*(h11.*h23-h13.*h21).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2-(h11.*h32-h12.*h31).*(h11.*h33-h13.*h31).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2-(h21.*h32-h22.*h31).*(h21.*h33-h23.*h31).*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;
h_33 = (h11.*h22-h12.*h21).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h11.*h32-h12.*h31).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2+(h21.*h32-h22.*h31).^2.*1.0./(h11.*h22.*h33-h11.*h23.*h32-h12.*h21.*h33+h12.*h23.*h31+h13.*h21.*h32-h13.*h22.*h31).^2;

% 
% % svd of H^-T*H^-1
a2 = -(h_11+h_22+h_33);
a1 = h_11.*h_22+h_11.*h_33+h_22.*h_33-(h_12.^2+h_13.^2+h_23.^2);
a0 = h_12.^2.*h_33+h_13.^2.*h_22+h_23.^2.*h_11-h_11.*h_22.*h_33-2*h_12.*h_13.*h_23;
a0(isnan(a0))=0; a1(isnan(a1))=0; a2(isnan(a2))=0;
Q = (3*a1-a2.^2)/9;
R = (9*a2.*a1-27*a0-2*a2.^3)/54;
S = (R+sqrt(Q.^3+R.^2)).^(1/3);
T = (R-sqrt(Q.^3+R.^2)).^(1/3);

% singular values
lam1 = -a2/3+(S+T);
lam2 = -a2/3-(S+T)/2-sqrt(3)/2*(S-T)*(1i);
lam3 = -a2/3-(S+T)/2+sqrt(3)/2*(S-T)*(1i);
lam2(imag(lam2)~=0) = 0;
lam3(imag(lam3)~=0) = 0;

Hcond = sqrt(lam1./lam3);
Hcond(isnan(Hcond))=0;
Hcond(sqrt(Hcond)<=th_min)=1e5;
% Hcond(Hcond<th_min)=1e5;
%S
h_11 = h_11./lam2-1; h_12 = h_12./lam2; h_13 = h_13./lam2; h_22 = h_22./lam2-1; h_23 = h_23./lam2; h_33 = h_33./lam2-1;
h_11(abs(h_11)<1e-4)=0; h_11(isnan(h_11))=0; h_11(isinf(h_11))=0;
h_12(abs(h_12)<1e-4)=0; h_12(isnan(h_12))=0; h_12(isinf(h_12))=0;
h_13(abs(h_13)<1e-4)=0; h_13(isnan(h_13))=0; h_13(isinf(h_13))=0;
h_22(abs(h_22)<1e-4)=0; h_22(isnan(h_22))=0; h_22(isinf(h_22))=0;
h_23(abs(h_23)<1e-4)=0; h_23(isnan(h_23))=0; h_23(isinf(h_23))=0;
h_33(abs(h_33)<1e-4)=0; h_33(isnan(h_33))=0; h_33(isinf(h_33))=0;
aa(:,:,1)=h_11; aa(:,:,2)=h_22; aa(:,:,3)=h_33; [~,I]= max(aa,[],3);

ep23 = sign(h_12.*h_13-h_11.*h_23); ep23(ep23 == 0) = 1; ep13 = sign(h_22.*h_13-h_12.*h_23); ep13(ep13 == 0) = 1; ep12 = sign(h_23.*h_13-h_12.*h_33); ep12(ep12 == 0) = 1;
trace_S = h_11 + h_22 + h_33; Ms11 = h_23.^2-h_22.*h_23; Ms22 = h_13.^2-h_11.*h_23; Ms33 = h_12.^2-h_11.*h_22;
%nu = 2*sqrt(1+trace_S-Ms11-Ms22-Ms33); r2 = sqrt(2+ trace_S + nu); te_2 = sqrt(2+ trace_S - nu);
%ep11 = sign(Ms11); ep11(ep11 == 0) = 1; ep22 = sign(Ms22); ep22(ep22 == 0) = 1; ep33 = sign(Ms33); ep33(ep33 == 0) = 1;
Ms11(Ms11<=0)=0; Ms22(Ms22<=0)=0; Ms33(Ms33<=0)=0;
% normals
na1 = h_11; na2 = h_12+sqrt(Ms33); na3 = h_13+ep23.*sqrt(Ms22);
nb1 = h_11; nb2 = h_12-sqrt(Ms33); nb3 = h_13-ep23.*sqrt(Ms22);
na1(I==2) = h_12(I==2)+sqrt(Ms33(I==2)); na2(I==2) = h_22(I==2); na3(I==2) = h_23(I==2)-ep13(I==2).*sqrt(Ms11(I==2));
nb1(I==2) = h_12(I==2)-sqrt(Ms33(I==2)); nb2(I==2) = h_22(I==2); nb3(I==2) = h_23(I==2)+ep13(I==2).*sqrt(Ms11(I==2));
na1(I==3) = h_13(I==3)+ep12(I==3).*sqrt(Ms22(I==3)); na2(I==3) = h_23(I==3)+sqrt(Ms11(I==3)); na3(I==3) = h_33(I==3);
nb1(I==3) = h_13(I==3)-ep12(I==3).*sqrt(Ms22(I==3)); nb2(I==3) = h_23(I==3)-sqrt(Ms11(I==3)); nb3(I==3) = h_33(I==3);

flag = zeros(size(na1));
flag(na1 ~= real(na1) | na2 ~= real(na2) | na3 ~= real(na3))=1;
na1(flag==1)=0; na2(flag==1)=0; na3(flag==1)=0;
flag = zeros(size(na2));
flag(nb1 ~= real(nb1) | nb2 ~= real(nb2) | nb3 ~= real(nb3))=1;
nb1(flag==1)=0; nb2(flag==1)=0; nb3(flag==1)=0;

k1a = na1./(na3 + u.*na1 +v.*na2); k2a = na2./(na3 + u.*na1 +v.*na2);
k1b = nb1./(nb3 + u.*nb1 +v.*nb2); k2b = nb2./(nb3 + u.*nb1 +v.*nb2);

na1(abs(k1a)>1)=0;na1(abs(k2a)>1)=0;
na2(abs(k1a)>1)=0;na2(abs(k2a)>1)=0;
na3(abs(k1a)>1)=0;na3(abs(k2a)>1)=0;

nb1(abs(k1b)>1)=0;nb1(abs(k2b)>1)=0;
nb2(abs(k1b)>1)=0;nb2(abs(k2b)>1)=0;
nb3(abs(k1b)>1)=0;nb3(abs(k2b)>1)=0;

na = sqrt(na1.^2+na2.^2+na3.^2); nb = sqrt(nb1.^2+nb2.^2+nb3.^2);
na1 = na1./na; na2 = na2./na; na3 = na3./na; nb1 = nb1./nb; nb2 = nb2./nb; nb3 = nb3./nb;
na1(isnan(na1))=0; na2(isnan(na2))=0; na3(isnan(na3))=0; nb1(isnan(nb1))=0; nb2(isnan(nb2))=0; nb3(isnan(nb3))=0;
na1(na3<0) = -na1(na3<0); na2(na3<0) = -na2(na3<0); na3(na3<0) = -na3(na3<0);
nb1(nb3<0) = -nb1(nb3<0); nb2(nb3<0) = -nb2(nb3<0); nb3(nb3<0) = -nb3(nb3<0);
na1(Hcond==1e5)=0; na2(Hcond==1e5)=0;na3(Hcond==1e5)=0;
nb1(Hcond==1e5)=0; nb2(Hcond==1e5)=0;nb3(Hcond==1e5)=0;



na1_ = h11.*na1+h12.*na2+h13.*na3;
na2_ = h21.*na1+h22.*na2+h23.*na3;
na3_ = h31.*na1+h32.*na2+h33.*na3;
na_ = sqrt(na1_.^2+na2_.^2+na3_.^2);
na1_ = na1_./na_; na2_ = na2_./na_; na3_ = na3_./na_;

nb1_ = h11.*nb1+h12.*nb2+h13.*nb3;
nb2_ = h21.*nb1+h22.*nb2+h23.*nb3;
nb3_ = h31.*nb1+h32.*nb2+h33.*nb3;
nb_ = sqrt(nb1_.^2+nb2_.^2+nb3_.^2);
nb1_ = nb1_./nb_; nb2_ = nb2_./nb_; nb3_ = nb3_./nb_;
na1_(isnan(na1_))=0; na2_(isnan(na2_))=0; na3_(isnan(na3_))=0; nb1_(isnan(nb1_))=0; nb2_(isnan(nb2_))=0; nb3_(isnan(nb3_))=0;

na1_(na3_<0) = -na1_(na3_<0); na2_(na3_<0) = -na2_(na3_<0); na3_(na3_<0) = -na3_(na3_<0);
nb1_(nb3_<0) = -nb1_(nb3_<0); nb2_(nb3_<0) = -nb2_(nb3_<0); nb3_(nb3_<0) = -nb3_(nb3_<0);



%visibility
visba = na3./(na1.*u + na2.*v + na3); visba(isnan(visba))=0; visba(visba<=0)=0; visba(visba>0)=1;
visbb = nb3./(nb1.*u + nb2.*v + nb3); visbb(isnan(visbb))=0; visbb(visbb<=0)=0; visbb(visbb>0)=1;
na1(visba==0)=0; na2(visba==0)=0; na3(visba==0)=0;
na1_(visba==0)=0; na2_(visba==0)=0; na3_(visba==0)=0;
nb1(visbb==0)=0; nb2(visbb==0)=0; nb3(visbb==0)=0;
nb1_(visbb==0)=0; nb2_(visbb==0)=0; nb3_(visbb==0)=0;


% disambiguate normals
ka1 = na1./(na3+u.*na1+v.*na2); ka2 = na2./(na3+u.*na1+v.*na2); ka1(isnan(ka1))=0; ka2(isnan(ka2))=0;
kb1 = nb1./(nb3+u.*nb1+v.*nb2); kb2 = nb2./(nb3+u.*nb1+v.*nb2); kb1(isnan(kb1))=0; kb2(isnan(kb2))=0;

t = min(ka1.^2+ka2.^2,kb1.^2+kb2.^2);
c = double(t==ka1.^2+ka2.^2);

nc1 = na1; nc2 = na2; nc3 = na3;
nc1(c==0)=nb1(c==0); nc2(c==0)=nb2(c==0); nc3(c==0)=nb3(c==0);
Nc = zeros(3*size(nc1,1),size(nc1,2)); 
Nc(1:3:end,:) = nc1; Nc(2:3:end,:) = nc2; Nc(3:3:end,:) = nc3;

nc1_ = na1_; nc2_ = na2_; nc3_ = na3_;
nc1_(c==0)=nb1_(c==0); nc2_(c==0)=nb2_(c==0); nc3_(c==0)=nb3_(c==0);
Nc_ = zeros(3*size(nc1,1),size(nc1,2)); 
Nc_(1:3:end,:) = nc1_; Nc_(2:3:end,:) = nc2_; Nc_(3:3:end,:) = nc3_;


