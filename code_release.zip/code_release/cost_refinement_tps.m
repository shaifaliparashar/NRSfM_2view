function [F,J] = cost_refinement_tps(x,q1,k1,k2,C1,D,V,EpsilonLambda1)
F=[];
L1 = x;

[M1, M2]=TPSCoeffDiff(q1,L1,C1,1e-4,EpsilonLambda1);
p1= M1*L1;
d_p1=M2*L1;
d_p1u=d_p1(1:2:end);
d_p1v=d_p1(2:2:end);
M21 = M2(1:2:end,:);
M22 = M2(2:2:end,:);
for i=1:length(k1)
    w=0;
    if k1(i)~=0 && k2(i)~=0

         w=1;
    end
    F1(i) = w*(k1(i) - (-d_p1u(i)/p1(i)));
    F2(i) = w*(k2(i) - (-d_p1v(i)/p1(i)));
    JF1(i,:)  =  w*(M21(i,:)./p1(i) - (d_p1u(i)/(p1(i)^2)).*M1(i,:));
    JF2(i,:)  =  w*(M22 (i,:)./p1(i) - (d_p1v(i)/(p1(i)^2)).*M1(i,:));
end
%smoothness
Fs= D*V'*L1;
Js = D*V';
%Js=blkdiag(Js,Js,Js);
F = [F1(:);F2(:);1e0*Fs(:)];
J = [JF1;JF2;1e0*Js];
end