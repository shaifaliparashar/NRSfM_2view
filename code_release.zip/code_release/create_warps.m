function [J21a,J21b,J21c,J21d,H21uva,H21uvb] = create_warps(I2u,I2v,ref,bbs_ij,ctrlpts_ij,ctrlptss_ij)

er = 1e-5;
t= 1e-3;
nC = 40;
J21a = zeros(size(I2u)); J21b = J21a; J21c=J21a; J21d = J21a; H21uva = J21a; H21uvb = J21a;
% calculate Eta_21 derivatives using schwarzian warps

for i = 1:size(I2u,1)
    q2 = [I2u(i,:);I2v(i,:)];
    
    bbs = bbs_ij(i);
    bbs = bbs{1};
    ctrlpts = ctrlpts_ij(i);
    ctrlpts = ctrlpts{1};
%     q1 = bbs_eval(bbs, ctrlpts, q2(1,:)',q2(2,:)',0,0);
%     mean(sum((q1-[I1u;I1v]).^2))
    dqu = bbs_eval(bbs, ctrlpts, q2(1,:)',q2(2,:)',1,0);
    dqv = bbs_eval(bbs, ctrlpts, q2(1,:)',q2(2,:)',0,1);
    
    if ref==1
        ctrlpts=ctrlptss_ij(i);
        ctrlpts=ctrlpts{1};
    end
    dquv = bbs_eval(bbs,ctrlpts,q2(1,:)',q2(2,:)',1,1);
    J21a(i,:) = dqu(1,:); J21b(i,:) = dqu(2,:);
    J21c(i,:) = dqv(1,:); J21d(i,:) = dqv(2,:);
    H21uva(i,:) = dquv(1,:); H21uvb(i,:) = dquv(2,:);
    %disp(fprintf('%f [ETA] Internal Rep error = %f',i,error))
    %     figure
    %     hold on
    %     plot(q1(1,:),q1(2,:),'or')
    %     plot(qw2(1,:),qw2(2,:),'*r')
    %     hold off
    %     axis equal
end

