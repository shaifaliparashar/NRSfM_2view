function Pe= estimate_points(P,q,qn,er)
Pe=zeros(3,size(q,2));
% create Ground truth
%er = 1e-4;
t= 1e-3;
nC = 20;
idx = find(P(1,:)~=0 & qn(1,:)~=0);
if ~isempty(idx)
    umin = min(q(1,:))-t; umax = max(q(1,:))+t;
    vmin = min(q(2,:))-t; vmax = max(q(2,:))+t;
    bbs = bbs_create(umin, umax, nC, vmin, vmax, nC, 3);
    coloc = bbs_coloc(bbs, qn(1,idx), qn(2,idx));
    lambdas = er*ones(nC-3, nC-3);
    bending = bbs_bending(bbs, lambdas);
    cpts = (coloc'*coloc + bending) \ (coloc'*P(1:3,idx)');
    ctrlpts = cpts';
    idx = find(q(1,:)~=0);
    Pe(:,idx) = bbs_eval(bbs, ctrlpts, q(1,idx)',q(2,idx)',0,0);
end



