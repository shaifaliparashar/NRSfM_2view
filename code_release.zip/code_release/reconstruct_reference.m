function [Nc,Pi] = reconstruct_reference(qgth,j,bbs,ctrlpts,ctrlptss,dense,ref,th_min)
[a,b,c,d,t1,t2] = warp_derivatives(qgth,j,ref,bbs,ctrlpts,ctrlptss,dense);
if ~dense
    q = qgth; q(2*(j-1)+1:2*(j-1)+2,:) = [];
    qref = qgth(2*j-1:2*j,:);
else
    q = qgth(:,1:dense:end); q(2*(j-1)+1:2*(j-1)+2,:) = [];
    qref = qgth(2*j-1:2*j,1:dense:end);
end
Nc = zeros(3,size(qref,2));
idx = find(qref(1,:)==0); q(:,idx)=0;idx = find(qref(1,:)~=0); qref = qref(:,idx);
Nc(:,idx) = compute_H(repmat(qref(1,:),size(a,1),1),repmat(qref(2,:),size(a,1),1),q(1:2:end,idx),q(2:2:end,idx),a(:,idx),b(:,idx),c(:,idx),d(:,idx),t1(:,idx),t2(:,idx),th_min);
Pi = calculate_depth(Nc,qgth(2*j-1,:),qgth(2*j,:),dense);
