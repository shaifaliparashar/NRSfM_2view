function Pref = refine_frame_tps(q1,k1,k2)

KLims= [min(q1(1,:)) max(q1(1,:)) min(q1(2,:)) max(q1(2,:))];
C1=TPSGenerateCenters(10,KLims);
EpsilonLambda1=TPSEpsilonLambda(C1,1e-4);

[L1,ZTZ1]=TPSWfromfeatures(q1,ones(1,size(q1,2)),C1,1e-4,1e-4,EpsilonLambda1);

[U, S, V]= svd(ZTZ1);
D=sqrt(S);
opt = optimset('Jacobian','on','Display','off','MaxIter',20, 'DerivativeCheck','off','UseParallel',true);
fun = @(x)cost_refinement_tps(x,q1,k1,k2,C1,D,V,EpsilonLambda1);

[L,~]=lsqnonlin(fun,L1,[],[],opt);
[~,Pe1]=TPSWarpDiff(q1,L,C1,1e-4,EpsilonLambda1);


Pref1 = Pe1.*[q1;ones(1,size(q1,2))];
Pref = Pref1;
end

