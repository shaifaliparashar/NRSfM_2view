close all
clear all
addpath(genpath('BBS'));
addpath(genpath('schwarps'));
addpath(genpath('TPS'));
addpath(genpath('nrsfm_score_v0.2'))

load('data_kinect_paper.mat')
visb = ones(size(q,1)/2,size(q,2));
idx=find(sum(abs(q))~=0);
q=q(:,idx);
P=P(:,idx);


% 2-view reconstruction
parfor j=1:size(q,1)/2
    
    [Ni{j},Pi{j}]   = reconstruct_reference(q,j,bbs_ij(:,j),ctrlpts_ij(:,j),ctrlpts_ijs(:,j),70,1,1.05);
    
end

% aligning reconstructed shapes to the ground truth to compare
for i=1:length(Pi)
    
    [d, Pi{i}, outliers] = nrsfm_score(Pi{i}, P(3*i-2:3*i,:));

end

for i=1:length(Pi)
    idx = find(visb(i,:)~=0);
    sc(i)= sqrt(mean(sum(P(3*i-2:3*i,idx).^2)));
    epi(i) = sqrt(mean(sum((Pi{i}(:,idx)-P(3*i-2:3*i,idx)).^2)))/sc(i);
   
end

epi(isnan(epi))=[];
mean(epi)
save('res.mat')


