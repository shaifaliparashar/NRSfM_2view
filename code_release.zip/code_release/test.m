close all
clear all
addpath(genpath('BBS'));
addpath(genpath('schwarps'));
addpath(genpath('TPS'));
addpath(genpath('nrsfm_score_v0.2'))

load('warps.mat')
idx=find(sum(abs(q))~=0);
q=q(:,idx);
P=P(:,idx);

parfor j=1:size(q,1)/2
    j
    [Ni{j},Pi{j}]   = reconstruct_reference(q,j,bbs_ij(:,j),ctrlpts_ij(:,j),ctrlpts_ijs(:,j),70,1,1.05);
    
end


for i=1:length(Pi)
    i
    [d, Pi{i}, outliers] = nrsfm_score(Pi{i}, P(3*i-2:3*i,:));
    
end

for i=1:length(Pi)
    i
    idx = find(visb(i,:)~=0);
    sc(i)= sqrt(mean(sum(P(3*i-2:3*i,idx).^2)));
    epi(i) = sqrt(mean(sum((Pi{i}(:,idx)-P(3*i-2:3*i,idx)).^2)))/sc(i);
   
end

epi(isnan(epi))=[];
mean(epi)
save('res.mat')


