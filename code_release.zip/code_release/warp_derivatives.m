function [J21a,J21b,J21c,J21d,t1,t2] = warp_derivatives(qgth,idx,ref,bbs,ctrlpts,ctrlptss,dense)
if ~dense
    q = qgth; q(2*(idx-1)+1:2*(idx-1)+2,:) = [];
    qref = qgth(2*idx-1:2*idx,:);
else
    q = qgth(:,1:dense:end); q(2*(idx-1)+1:2*(idx-1)+2,:) = [];
    qref = qgth(2*idx-1:2*idx,1:dense:end);
end
bbs(idx)=[]; ctrlpts(idx)=[]; ctrlptss(idx)=[];
[J21a,J21b,J21c,J21d,H21uva,H21uvb] = create_warps(q(1:2:end,:),q(2:2:end,:),ref,bbs,ctrlpts,ctrlptss);
J12a = J21d./(J21a.*J21d-J21b.*J21c); J12b = -J21b./(J21a.*J21d-J21b.*J21c);
J12c = -J21c./(J21a.*J21d-J21b.*J21c); J12d = J21a./(J21a.*J21d-J21b.*J21c);
t1 = -(J12b.*H21uva + J12d.*H21uvb); t2 = -(J12a.*H21uva + J12c.*H21uvb);
t1(isnan(t1))=0;t2(isnan(t2))=0;
idx = find(qref(1,:)==0);
J21a(:,idx)=0; J21b(:,idx)=0; J21c(:,idx)=0; J21d(:,idx)=0; t1(:,idx)=0; t2(:,idx)=0;
end